<?php
$post_tags = get_the_tags($post->ID);
?>

<article <?php (post_class('post-in-grid')); ?>>
  <div class="helper-row-sticky">
    <header class="post-in-grid__header">
      <img src="<?php echo e(get_the_post_thumbnail_url($post->ID, 'featured-grid')); ?>" alt="<?php echo e(get_the_title($post->ID)); ?>">
    </header>

    <div class="article-main">
      <?php echo $__env->make('partials/entry-meta-time', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h2 class="entry-title"><a href="<?php echo e(get_permalink()); ?>"><?php echo e(get_the_title()); ?></a></h2>

      <?php if($post_tags): ?>
        <?php echo $__env->make('partials.post-tags', [
          'tags' => $post_tags
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>

      <div class="entry-summary">
        <?php (the_excerpt()); ?>
      </div>

      <div class="entry-social-meta">
        <div class="entry-social-meta__favs">
          <span class="udck-ic-heart"></span> 0 favs
        </div>

        <div class="entry-social-meta__comments">
          <span class="udck-ic-comment"></span> 0 comments
        </div>
      </div>
    </div>
  </div>
</article>
