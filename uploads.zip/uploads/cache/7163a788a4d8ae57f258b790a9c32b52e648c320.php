<footer class="content-info">
  <div class="sage-wrapper container">
    <div class="row">
      <div class="newsletter-form prefooter">
        <h1 class="newsletter-fom__heading h1 c-light">Subscribe to Duck News</h1>
        <?php (dynamic_sidebar('newsletter-footer')); ?>
      </div>
    </div>
  </div>
  <div class="real-footer">
    <div class="container">
      <div class="row">
        <div class="footer-copyright">
          <div class="footer-logo">
            <?php if(function_exists('the_custom_logo')): ?>
              <?php echo e(the_custom_logo()); ?>

            <?php else: ?>
              <a class="brand" href="<?php echo e(home_url('/')); ?>"><?php echo e(get_bloginfo('name', 'display')); ?></a>
            <?php endif; ?>
          </div>

          <div class="footer-copy-text">
            <?php (dynamic_sidebar('copy-footer')); ?>
          </div>
        </div>

        <div class="footer-social">
          <?php (dynamic_sidebar('social-footer')); ?>
        </div>
      </div>
    </div>
  </div>
</footer>
