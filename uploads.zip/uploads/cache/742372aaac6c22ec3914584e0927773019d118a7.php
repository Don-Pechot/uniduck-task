<header class="banner">
  <div class="sage-wrapper container">
    <div class="row">
      <div class="header-logo">
        <?php if(function_exists('the_custom_logo')): ?>
          <?php echo e(the_custom_logo()); ?>

        <?php else: ?>
          <a class="brand" href="<?php echo e(home_url('/')); ?>"><?php echo e(get_bloginfo('name', 'display')); ?></a>
        <?php endif; ?>
      </div>

      <div class="header-main-menu">
        <nav class="header-main-menu__nav nav-primary">
          <?php if(has_nav_menu('primary_navigation')): ?>
            <?php echo wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav']); ?>

          <?php endif; ?>
        </nav>
        <div class="header-main-menu__toggle jsToggleMenu">
          <span class="udck-menu"></span>
        </div>
      </div>
    </div>
  </div>
</header>
