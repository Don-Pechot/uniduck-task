<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <?php echo $__env->make('partials.page-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>



    <?php if(!have_posts()): ?>
      <div class="alert alert-warning">
        <?php echo e(__('Sorry, no results were found.', 'sage')); ?>

      </div>
      <?php echo get_search_form(false); ?>

    <?php endif; ?>

    <div class="post-grid">
      <div class="row">
        <?php while(have_posts()): ?> <?php (the_post()); ?>
          <?php echo $__env->make('partials.content-'.get_post_type(), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endwhile; ?>
      </div>
    </div>


    <?php if(function_exists(wp_pagenavi())): ?>
      <?php echo e(wp_pagenavi()); ?>

    <?php endif; ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>