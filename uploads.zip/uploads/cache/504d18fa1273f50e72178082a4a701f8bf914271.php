<?php
$post_tags = get_the_tags($post->ID);
$random_post = get_posts(array('orderby' => 'rand', 'posts_per_page' => 1, 'post__not_in' => get_option( 'sticky_posts' )));
?>

<article <?php (post_class()); ?>>
  <header class="post-header">
    <div class="post-header__featured-image">
      <?php if(get_the_post_thumbnail_url()): ?>
        <div class="post-header__featured-image-src"
              style="background-image: url(<?php echo get_the_post_thumbnail_url($post->ID, 'featured-single-post'); ?>)">
        </div>
        
      <?php endif; ?>
    </div>
    <div class="post-header__meta-overlay">
      <div class="title-and-meta">
        <h1 class="entry-title"><?php echo e(get_the_title()); ?></h1>
        <?php echo $__env->make('partials/entry-meta-author', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>

      <div class="back-to-blog">
        <a href="<?php echo home_url(); ?>">Back to blog</a>
      </div>
    </div>
  </header>


  <div class="entry-content">

    <?php if(get_field('post_featured_text', $post->ID)): ?>
      <div class="container">
        <div class="row">
          <section class="entry-content__featured">
            <?php echo get_field('post_featured_text', $post->ID); ?>

          </section>
        </div>
      </div>
    <?php endif; ?>

    <div class="container">
      <div class="row">
        <div class="entry-content__main">
          <div class="row-align-around">
            <?php (the_content()); ?>

            <?php if($post_tags): ?>
              <?php echo $__env->make('partials.post-tags', [
                'tags' => $post_tags
              ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>

            
            <div class="random-post">
              <h4 class="h4 random-post__heading">More magic</h4>
              <div class="row">
                <div class="random-post__thumbnail">
                  <img src="<?php echo get_the_post_thumbnail_url($random_post[0]->ID, 'featured-grid'); ?>" alt="Next post thumb">
                </div>

                <div class="random-post__content">
                  <h4 class="h4 random-post__title"><?php echo e($random_post[0]->post_title); ?></h4>
                  <p class="random-post__excerpt"><?php echo get_the_excerpt($random_post[0]->ID); ?></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <footer>

  </footer>
  
</article>
