<div class="page-header">
  <h1><?php echo App::title(); ?></h1>
  <?php if(is_home()): ?>
    <?php echo e(get_search_form()); ?>

  <?php endif; ?>
</div>
