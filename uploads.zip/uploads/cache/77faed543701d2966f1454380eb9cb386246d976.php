<div class="post-tags">
  <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="post-tag" href="<?php echo get_term_link($tag->term_id, 'post_tag'); ?>">
      <?php echo e($tag->name); ?>

    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
